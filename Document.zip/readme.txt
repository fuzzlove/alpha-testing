
Please extract the entire archive to a folder and then open the 'Documents' file folder to view files.